package com.exam.service;

public interface RoleService {
}
