package com.exam.controller;


import com.exam.model.exam.Category;
import com.exam.model.exam.Quiz;
import com.exam.service.QuizService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.parameters.P;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/quiz")
@CrossOrigin("*")
public class QuizController {

    @Autowired
    private QuizService quizService;



    //add quiz
    @PostMapping("/")
    public ResponseEntity<Quiz> addCategory(@RequestBody Quiz quiz){
        //Quiz quiz1=this.quizService.addQuiz(quiz);
        return ResponseEntity.ok(this.quizService.addQuiz(quiz));
    }



    //update quiz
    @PutMapping("/")
    public ResponseEntity<Quiz> updateQuiz(@RequestBody Quiz quiz){
        return ResponseEntity.ok(this.quizService.updateQuiz(quiz));
    }

    //get Quiz
    @GetMapping("/")
    public ResponseEntity<?> quizzes(){

        return ResponseEntity.ok(this.quizService.getQuizzes());
    }


    //get SIngle Quiz
    @GetMapping("/{qid}")
    public Quiz quiz(@PathVariable("qid") Long qid){
        return this.quizService.getQuiz(qid);
    }

    //delete the quiz
    @DeleteMapping("/{qid}")
    public void deleteQuiz(@PathVariable("qid") Long qid){
            this.quizService.deleteQuiz(qid);
    }



    @GetMapping("/category/{cid}")
        public List<?> getQuizzesOfCategory(@PathVariable("cid") Long cid){

            Category category= new Category();
            category.setCid(cid);
            return this.quizService.getQuizzesOfCategory(category);
        }


    //get active quizzes
    @GetMapping("/active")
    public List<?> getActiveQuizzes(){
       return this.quizService.getActiveQuizzes();
    }
    @GetMapping("/category/active/{cid}")
    public List<?> getActiveQuizzes(@PathVariable("cid") Long cid){
        Category category=new Category();
        category.setCid(cid);
       return this.quizService.getActiveQuizzesOfCategory(category);
    }


}




